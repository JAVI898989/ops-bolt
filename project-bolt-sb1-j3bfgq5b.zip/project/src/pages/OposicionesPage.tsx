import React, { useState } from 'react';
import { Search, Filter, ArrowRight } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';

const OposicionesPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = [
    { id: 'administracion', name: 'Administración General del Estado' },
    { id: 'justicia', name: 'Justicia' },
    { id: 'hacienda', name: 'Hacienda y Economía' },
    { id: 'sanidad', name: 'Sanidad' },
    { id: 'educacion', name: 'Educación' },
    { id: 'seguridad', name: 'Seguridad y Policía' },
    { id: 'bomberos', name: 'Bomberos' },
    { id: 'penitenciarias', name: 'Instituciones Penitenciarias' },
    { id: 'otros', name: 'Otros' },
    { id: 'medioambientales', name: 'Agentes Medioambientales' },
    { id: 'militares', name: 'Militares' },
  ];

  // Ejemplo de datos de oposiciones
  const oposiciones = [
    { 
      id: 1, 
      title: 'Auxiliar Administrativo del Estado',
      category: 'administracion',
      description: 'Oposición para acceder al Cuerpo de Auxiliares Administrativos del Estado.',
      difficulty: 'media',
      lastUpdate: '2023-05-15',
      popularity: 95,
      image: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    { 
      id: 2, 
      title: 'Policía Nacional (Escala Básica)',
      category: 'seguridad',
      description: 'Oposición para acceder al Cuerpo Nacional de Policía en su Escala Básica.',
      difficulty: 'alta',
      lastUpdate: '2023-06-20',
      popularity: 90,
      image: 'https://images.pexels.com/photos/1693095/pexels-photo-1693095.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    { 
      id: 3, 
      title: 'Maestro de Educación Primaria',
      category: 'educacion',
      description: 'Oposición para acceder al Cuerpo de Maestros en la especialidad de Educación Primaria.',
      difficulty: 'media',
      lastUpdate: '2023-04-10',
      popularity: 88,
      image: 'https://images.pexels.com/photos/3769714/pexels-photo-3769714.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    { 
      id: 4, 
      title: 'Enfermería',
      category: 'sanidad',
      description: 'Oposición para acceder al Cuerpo de Enfermería del Sistema Nacional de Salud.',
      difficulty: 'alta',
      lastUpdate: '2023-06-05',
      popularity: 92,
      image: 'https://images.pexels.com/photos/4173251/pexels-photo-4173251.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    { 
      id: 5, 
      title: 'Administrativo del Estado',
      category: 'administracion',
      description: 'Oposición para acceder al Cuerpo de Administrativos del Estado.',
      difficulty: 'media',
      lastUpdate: '2023-05-30',
      popularity: 85,
      image: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    { 
      id: 6, 
      title: 'Bombero',
      category: 'bomberos',
      description: 'Oposición para acceder al Cuerpo de Bomberos municipales.',
      difficulty: 'muy alta',
      lastUpdate: '2023-06-15',
      popularity: 86,
      image: 'https://images.pexels.com/photos/4400353/pexels-photo-4400353.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    { 
      id: 7, 
      title: 'Agente de Hacienda',
      category: 'hacienda',
      description: 'Oposición para acceder al Cuerpo de Agentes de la Hacienda Pública.',
      difficulty: 'media',
      lastUpdate: '2023-05-10',
      popularity: 80,
      image: 'https://images.pexels.com/photos/3760529/pexels-photo-3760529.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    { 
      id: 8, 
      title: 'Auxilio Judicial',
      category: 'justicia',
      description: 'Oposición para acceder al Cuerpo de Auxilio Judicial de la Administración de Justicia.',
      difficulty: 'media',
      lastUpdate: '2023-06-10',
      popularity: 78,
      image: 'https://images.pexels.com/photos/5668792/pexels-photo-5668792.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
  ];

  // Filtrar oposiciones según búsqueda y categoría
  const filteredOposiciones = oposiciones.filter(oposicion => {
    const matchesSearch = oposicion.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory ? oposicion.category === selectedCategory : true;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-8 pb-16">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mb-12">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Oposiciones
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Explora todas las oposiciones disponibles y encuentra la adecuada para ti
          </p>
        </div>
        
        {/* Filtros y búsqueda */}
        <div className="mb-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="col-span-2">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Buscar oposición..."
                className="pl-10 pr-4 py-2 w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-5 w-5 text-gray-400" />
              </div>
              <select
                className="pl-10 pr-4 py-2 w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
                value={selectedCategory || ''}
                onChange={(e) => setSelectedCategory(e.target.value || null)}
              >
                <option value="">Todas las categorías</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
        
        {/* Categorías */}
        <div className="mb-12 flex overflow-x-auto pb-4 scrollbar-hide space-x-4">
          <button
            className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              selectedCategory === null
                ? 'bg-blue-900 dark:bg-blue-800 text-white'
                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
            }`}
            onClick={() => setSelectedCategory(null)}
          >
            Todas
          </button>
          
          {categories.map((category) => (
            <button
              key={category.id}
              className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category.id
                  ? 'bg-blue-900 dark:bg-blue-800 text-white'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
              }`}
              onClick={() => setSelectedCategory(category.id)}
            >
              {category.name}
            </button>
          ))}
        </div>
        
        {/* Listado de oposiciones */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredOposiciones.map((oposicion) => (
            <Card 
              key={oposicion.id} 
              hoverable 
              className="h-full overflow-hidden"
              onClick={() => window.location.href = `/oposicion/${oposicion.id}`}
            >
              <div className="relative h-48">
                <img 
                  src={oposicion.image} 
                  alt={oposicion.title} 
                  className="w-full h-full object-cover transition-transform hover:scale-105"
                />
                <div className="absolute top-2 right-2 bg-blue-900 text-white text-xs font-semibold px-2 py-1 rounded">
                  {oposicion.difficulty}
                </div>
              </div>
              
              <CardContent className="p-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {oposicion.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3 line-clamp-2">
                  {oposicion.description}
                </p>
                <div className="flex justify-between items-center mt-4">
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    Actualizado: {new Date(oposicion.lastUpdate).toLocaleDateString('es-ES')}
                  </span>
                  <div className="flex items-center">
                    <span className="text-xs font-medium text-blue-900 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 flex items-center">
                      Ver detalles
                      <ArrowRight className="ml-1 h-3 w-3" />
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {filteredOposiciones.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-300 text-lg">
              No se encontraron oposiciones que coincidan con tu búsqueda.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default OposicionesPage;