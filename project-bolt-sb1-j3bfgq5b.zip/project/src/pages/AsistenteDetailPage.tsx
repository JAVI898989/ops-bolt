import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { MessageSquare, FileText, BookOpen, LineChart, Smile, ArrowLeft, Clock, Send, PlusCircle, Paperclip } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/Tabs';
import Button from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';

const AsistenteDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState('chat');
  const [message, setMessage] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{role: 'user' | 'assistant', content: string}>>([
    {
      role: 'assistant',
      content: '¡Hola! Soy tu asistente para la preparación de oposiciones. ¿En qué puedo ayudarte hoy?'
    }
  ]);

  // Datos de ejemplo del asistente
  const asistente = {
    id: 1,
    title: 'Auxiliar Administrativo',
    category: 'Administración General del Estado',
    description: 'Asistente especializado en la preparación de oposiciones para Auxiliar Administrativo del Estado.',
    features: ['Temario completo', 'Tests personalizados', 'Simulacros de examen', 'Seguimiento de progreso'],
    icon: <MessageSquare className="h-8 w-8" />,
    color: 'blue',
    price: 19.99,
    rating: 4.8,
    reviews: 124
  };

  const temas = [
    { id: 1, title: 'La Constitución Española de 1978', content: '...' },
    { id: 2, title: 'La organización territorial del Estado', content: '...' },
    { id: 3, title: 'La Administración General del Estado', content: '...' },
    { id: 4, title: 'El procedimiento administrativo común', content: '...' },
    { id: 5, title: 'Los contratos del sector público', content: '...' },
    { id: 6, title: 'El presupuesto del Estado', content: '...' },
    { id: 7, title: 'La gestión económica y financiera', content: '...' },
    { id: 8, title: 'Los empleados públicos', content: '...' },
    { id: 9, title: 'Ofimática', content: '...' },
    { id: 10, title: 'Atención al ciudadano', content: '...' },
  ];

  const tests = [
    { id: 1, title: 'Test general - Nivel básico', questions: 20, time: 30, difficulty: 'Fácil' },
    { id: 2, title: 'Test general - Nivel medio', questions: 30, time: 45, difficulty: 'Media' },
    { id: 3, title: 'Test general - Nivel avanzado', questions: 40, time: 60, difficulty: 'Difícil' },
    { id: 4, title: 'Test específico - Constitución', questions: 15, time: 20, difficulty: 'Media' },
    { id: 5, title: 'Test específico - Procedimiento Administrativo', questions: 15, time: 20, difficulty: 'Alta' },
  ];

  const progreso = {
    temasCompletados: 3,
    totalTemas: 10,
    testsRealizados: 8,
    puntuacionMedia: 7.2,
    tiempoEstudio: 24.5,
    ultimaConexion: '2023-10-10'
  };

  const handleSubmitMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (message.trim() === '') return;
    
    // Añadir mensaje del usuario
    const newUserMessage = { role: 'user' as const, content: message };
    setChatMessages([...chatMessages, newUserMessage]);
    
    // Simulación respuesta del asistente (en un caso real, aquí iría la llamada a la API)
    setTimeout(() => {
      const assistantResponse = { 
        role: 'assistant' as const, 
        content: 'Entiendo tu pregunta. Voy a ayudarte con información sobre el proceso de oposición para Auxiliar Administrativo. ¿Hay algo específico del temario o del proceso que te interese conocer?' 
      };
      setChatMessages(prevMessages => [...prevMessages, assistantResponse]);
    }, 1000);
    
    setMessage('');
  };

  const handleGenerateTest = () => {
    // Lógica para generar un test personalizado
    console.log('Generando test personalizado...');
  };

  const handleGenerateTemario = () => {
    // Lógica para generar un temario personalizado
    console.log('Generando temario personalizado...');
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-8 pb-16">
      <div className="container mx-auto px-4 md:px-6">
        {/* Encabezado */}
        <div className="mb-8 flex flex-col md:flex-row justify-between items-start gap-4">
          <div className="flex items-center">
            <a 
              href="/asistentes" 
              className="mr-4 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-300"
            >
              <ArrowLeft size={20} />
            </a>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">
                Asistente IA: {asistente.title}
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                {asistente.category}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-sm text-gray-600 dark:text-gray-300">
              <span className="inline-flex items-center mr-4">
                <svg className="w-4 h-4 text-yellow-500 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                </svg>
                {asistente.rating} ({asistente.reviews} reseñas)
              </span>
              <span className="inline-flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                Actualizado: hace 2 semanas
              </span>
            </div>
            <Button 
              variant="primary"
              size="sm"
            >
              Suscribirme por {asistente.price}€/mes
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-16">
          <TabsList className="mb-8">
            <TabsTrigger value="chat">
              <MessageSquare className="h-4 w-4 mr-2" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="temario">
              <BookOpen className="h-4 w-4 mr-2" />
              Temario
            </TabsTrigger>
            <TabsTrigger value="test">
              <FileText className="h-4 w-4 mr-2" />
              Test
            </TabsTrigger>
            <TabsTrigger value="progreso">
              <LineChart className="h-4 w-4 mr-2" />
              Progreso
            </TabsTrigger>
            <TabsTrigger value="motivacion">
              <Smile className="h-4 w-4 mr-2" />
              Motivación
            </TabsTrigger>
          </TabsList>
          
          {/* Tab de Chat */}
          <TabsContent value="chat" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Card className="h-[600px] flex flex-col">
                  <div className="flex-grow overflow-y-auto p-4">
                    {chatMessages.map((msg, index) => (
                      <div 
                        key={index} 
                        className={`mb-4 flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div 
                          className={`max-w-[80%] rounded-lg p-3 ${
                            msg.role === 'user' 
                              ? 'bg-blue-900 text-white' 
                              : 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200'
                          }`}
                        >
                          {msg.content}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="border-t border-gray-200 dark:border-gray-700 p-4">
                    <form onSubmit={handleSubmitMessage} className="flex gap-2">
                      <button 
                        type="button" 
                        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500"
                      >
                        <Paperclip size={20} />
                      </button>
                      <input
                        type="text"
                        placeholder="Escribe tu mensaje..."
                        className="flex-grow px-4 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                      />
                      <Button 
                        type="submit" 
                        variant="primary"
                        size="sm"
                        className="rounded-full p-2 w-10 h-10 flex items-center justify-center"
                      >
                        <Send size={18} />
                      </Button>
                    </form>
                  </div>
                </Card>
              </div>
              
              <div>
                <Card className="mb-6">
                  <CardContent className="p-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                      Sugerencias
                    </h3>
                    <div className="space-y-2">
                      {['¿Cuál es el temario completo?', '¿Cómo es el examen?', '¿Cuáles son los requisitos?', '¿Cuándo es la próxima convocatoria?'].map((suggestion, index) => (
                        <button
                          key={index}
                          className="w-full text-left p-2 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-300"
                          onClick={() => setMessage(suggestion)}
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                      Comandos rápidos
                    </h3>
                    <div className="space-y-2">
                      <button
                        className="w-full flex items-center justify-between p-2 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-300"
                        onClick={() => setMessage('/generar_test')}
                      >
                        <span>/generar_test</span>
                        <FileText size={16} />
                      </button>
                      <button
                        className="w-full flex items-center justify-between p-2 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-300"
                        onClick={() => setMessage('/resumen_tema')}
                      >
                        <span>/resumen_tema</span>
                        <BookOpen size={16} />
                      </button>
                      <button
                        className="w-full flex items-center justify-between p-2 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-300"
                        onClick={() => setMessage('/mi_progreso')}
                      >
                        <span>/mi_progreso</span>
                        <LineChart size={16} />
                      </button>
                      <button
                        className="w-full flex items-center justify-between p-2 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-300"
                        onClick={() => setMessage('/motivacion')}
                      >
                        <span>/motivacion</span>
                        <Smile size={16} />
                      </button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Tab de Temario */}
          <TabsContent value="temario" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Card>
                  <CardContent className="p-6">
                    <div className="mb-6">
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                        Temario completo
                      </h2>
                      <p className="text-gray-600 dark:text-gray-300">
                        Explora todos los temas de la oposición o genera un temario personalizado
                      </p>
                    </div>
                    
                    <div className="space-y-4 mb-8">
                      {temas.map((tema, index) => (
                        <div
                          key={tema.id}
                          className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:shadow transition-shadow"
                        >
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-900 dark:text-blue-200 flex items-center justify-center font-medium mr-4">
                              {index + 1}
                            </div>
                            <h3 className="font-medium text-gray-900 dark:text-white flex-grow">
                              {tema.title}
                            </h3>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => window.location.href = `/tema/${tema.id}`}
                            >
                              Ver tema
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-4 flex justify-center">
                      <Button 
                        variant="primary"
                        onClick={handleGenerateTemario}
                        leftIcon={<PlusCircle size={18} />}
                      >
                        Generar temario personalizado
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <Card className="mb-6">
                  <CardContent className="p-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                      Progreso del temario
                    </h3>
                    <div className="mb-2">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-600 dark:text-gray-300">Temas completados</span>
                        <span className="font-medium text-gray-900 dark:text-white">{progreso.temasCompletados}/{progreso.totalTemas}</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                        <div 
                          className="bg-blue-900 dark:bg-blue-700 h-2.5 rounded-full" 
                          style={{ width: `${(progreso.temasCompletados / progreso.totalTemas) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Última actualización: {new Date(progreso.ultimaConexion).toLocaleDateString('es-ES')}
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                      Recomendaciones
                    </h3>
                    <div className="space-y-2">
                      <div className="p-2 text-sm rounded-md bg-yellow-50 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-200">
                        <p className="font-medium">Enfócate en el Tema 4</p>
                        <p className="text-xs mt-1">Basado en tus resultados de tests anteriores</p>
                      </div>
                      <div className="p-2 text-sm rounded-md bg-green-50 dark:bg-green-900/20 text-green-800 dark:text-green-200">
                        <p className="font-medium">Buen progreso en Tema 1</p>
                        <p className="text-xs mt-1">Mantén la consistencia</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Tab de Test */}
          <TabsContent value="test" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Card>
                  <CardContent className="p-6">
                    <div className="mb-6">
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                        Tests disponibles
                      </h2>
                      <p className="text-gray-600 dark:text-gray-300">
                        Realiza tests predefinidos o genera tests personalizados según tus necesidades
                      </p>
                    </div>
                    
                    <div className="space-y-4 mb-8">
                      {tests.map((test) => (
                        <div
                          key={test.id}
                          className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:shadow transition-shadow"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="font-medium text-gray-900 dark:text-white">
                                {test.title}
                              </h3>
                              <div className="flex items-center mt-1 text-sm text-gray-500 dark:text-gray-400">
                                <span className="inline-flex items-center mr-3">
                                  <FileText className="h-4 w-4 mr-1" />
                                  {test.questions} preguntas
                                </span>
                                <span className="inline-flex items-center mr-3">
                                  <Clock className="h-4 w-4 mr-1" />
                                  {test.time} minutos
                                </span>
                                <span className="inline-flex items-center">
                                  <svg className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M17 9L13.9558 13.5662C13.5299 14.2051 12.5728 14.1455 12.2294 13.4587L11.5706 12.1413C11.2272 11.4545 10.2701 11.3949 9.84424 12.0338L7 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                                    <path d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="currentColor" strokeWidth="2"/>
                                  </svg>
                                  Dificultad: {test.difficulty}
                                </span>
                              </div>
                            </div>
                            <Button 
                              variant="primary" 
                              size="sm"
                              onClick={() => window.location.href = `/test/${test.id}`}
                            >
                              Iniciar test
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-4 flex justify-center">
                      <Button 
                        variant="primary"
                        onClick={handleGenerateTest}
                        leftIcon={<PlusCircle size={18} />}
                      >
                        Generar test personalizado
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <Card className="mb-6">
                  <CardContent className="p-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                      Estadísticas de tests
                    </h3>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-600 dark:text-gray-300">Tests realizados</span>
                          <span className="font-medium text-gray-900 dark:text-white">{progreso.testsRealizados}</span>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-600 dark:text-gray-300">Puntuación media</span>
                          <span className="font-medium text-gray-900 dark:text-white">{progreso.puntuacionMedia.toFixed(1)}/10</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                          <div 
                            className="bg-green-600 dark:bg-green-700 h-2.5 rounded-full" 
                            style={{ width: `${(progreso.puntuacionMedia / 10) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                      Opciones de test
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Número de preguntas
                        </label>
                        <select className="w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-gray-900 dark:text-gray-100">
                          <option value="10">10 preguntas</option>
                          <option value="20">20 preguntas</option>
                          <option value="30">30 preguntas</option>
                          <option value="40">40 preguntas</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Dificultad
                        </label>
                        <select className="w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-gray-900 dark:text-gray-100">
                          <option value="easy">Fácil</option>
                          <option value="medium">Media</option>
                          <option value="hard">Difícil</option>
                          <option value="mixed">Mixta</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Temas
                        </label>
                        <select className="w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-gray-900 dark:text-gray-100">
                          <option value="all">Todos los temas</option>
                          <option value="1">Tema 1</option>
                          <option value="2">Tema 2</option>
                          <option value="3">Tema 3</option>
                          <option value="4">Tema 4</option>
                        </select>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Tab de Progreso */}
          <TabsContent value="progreso" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6 flex flex-col items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-blue-100 dark:bg-blue-900/20 flex items-center justify-center mb-4">
                    <BookOpen className="h-8 w-8 text-blue-900 dark:text-blue-400" />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gray-900 dark:text-white">
                      {progreso.temasCompletados}/{progreso.totalTemas}
                    </div>
                    <p className="text-gray-500 dark:text-gray-400">Temas completados</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 flex flex-col items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center mb-4">
                    <FileText className="h-8 w-8 text-green-700 dark:text-green-400" />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gray-900 dark:text-white">
                      {progreso.testsRealizados}
                    </div>
                    <p className="text-gray-500 dark:text-gray-400">Tests realizados</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 flex flex-col items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-yellow-100 dark:bg-yellow-900/20 flex items-center justify-center mb-4">
                    <svg className="h-8 w-8 text-yellow-700 dark:text-yellow-400" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M8 14V17M12 14V17M16 14V17M3 21H21M3 10H21M3 7L12 3L21 7M4 10H20V21H4V10Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gray-900 dark:text-white">
                      {progreso.puntuacionMedia.toFixed(1)}
                    </div>
                    <p className="text-gray-500 dark:text-gray-400">Nota media</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 flex flex-col items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center mb-4">
                    <Clock className="h-8 w-8 text-purple-700 dark:text-purple-400" />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gray-900 dark:text-white">
                      {progreso.tiempoEstudio}h
                    </div>
                    <p className="text-gray-500 dark:text-gray-400">Tiempo de estudio</p>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                      Progreso por tema
                    </h3>
                    <div className="space-y-4">
                      {temas.map((tema, index) => (
                        <div key={tema.id} className="mb-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-700 dark:text-gray-300">Tema {index + 1}: {tema.title}</span>
                            <span className="font-medium text-gray-900 dark:text-white">
                              {index < 3 ? '100%' : index < 6 ? '60%' : '0%'}
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                            <div 
                              className={`h-2.5 rounded-full ${
                                index < 3 
                                  ? 'bg-green-600 dark:bg-green-700' 
                                  : index < 6 
                                    ? 'bg-yellow-500 dark:bg-yellow-600' 
                                    : 'bg-gray-300 dark:bg-gray-600'
                              }`} 
                              style={{ width: index < 3 ? '100%' : index < 6 ? '60%' : '0%' }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <Card className="mb-6">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                      Recomendaciones
                    </h3>
                    <div className="space-y-4">
                      <div className="p-3 rounded-md bg-blue-50 dark:bg-blue-900/20 text-blue-900 dark:text-blue-200">
                        <h4 className="font-medium mb-1">Enfócate en el Tema 7</h4>
                        <p className="text-sm">Este tema aún no lo has empezado y es importante para la convocatoria actual.</p>
                      </div>
                      <div className="p-3 rounded-md bg-yellow-50 dark:bg-yellow-900/20 text-yellow-900 dark:text-yellow-200">
                        <h4 className="font-medium mb-1">Refuerza el Tema 4</h4>
                        <p className="text-sm">Tus resultados en los tests de este tema están por debajo de la media.</p>
                      </div>
                      <div className="p-3 rounded-md bg-green-50 dark:bg-green-900/20 text-green-900 dark:text-green-200">
                        <h4 className="font-medium mb-1">¡Buen progreso!</h4>
                        <p className="text-sm">Has completado el 30% del temario. Mantén el ritmo para terminar a tiempo.</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                      Objetivos
                    </h3>
                    <div className="space-y-3">
                      <div className="flex items-center p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                        <input type="checkbox" className="h-4 w-4 text-blue-900 rounded border-gray-300 focus:ring-blue-500" />
                        <span className="ml-3 text-sm text-gray-700 dark:text-gray-300">Completar Tema 5 esta semana</span>
                      </div>
                      <div className="flex items-center p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                        <input type="checkbox" className="h-4 w-4 text-blue-900 rounded border-gray-300 focus:ring-blue-500" checked />
                        <span className="ml-3 text-sm text-gray-700 dark:text-gray-300">Realizar 3 tests</span>
                      </div>
                      <div className="flex items-center p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                        <input type="checkbox" className="h-4 w-4 text-blue-900 rounded border-gray-300 focus:ring-blue-500" />
                        <span className="ml-3 text-sm text-gray-700 dark:text-gray-300">Mejorar nota media a 8</span>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full mt-2"
                        leftIcon={<PlusCircle size={16} />}
                      >
                        Añadir objetivo
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Tab de Motivación */}
          <TabsContent value="motivacion" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <Card>
                  <CardContent className="p-6">
                    <div className="mb-8 text-center">
                      <div className="w-20 h-20 rounded-full bg-yellow-100 dark:bg-yellow-900/20 flex items-center justify-center mx-auto mb-4">
                        <Smile className="h-10 w-10 text-yellow-700 dark:text-yellow-400" />
                      </div>
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                        Tu asistente motivacional
                      </h2>
                      <p className="text-gray-600 dark:text-gray-300 max-w-xl mx-auto">
                        Te ayudamos a mantener la motivación y constancia en tu preparación para las oposiciones
                      </p>
                    </div>
                    
                    <div className="bg-blue-50 dark:bg-blue-900/10 p-6 rounded-lg mb-8">
                      <h3 className="text-xl font-semibold text-blue-900 dark:text-blue-400 mb-3">
                        Frase del día
                      </h3>
                      <blockquote className="text-lg italic text-gray-700 dark:text-gray-300 mb-4">
                        "El éxito no es la clave de la felicidad. La felicidad es la clave del éxito. Si amas lo que haces, tendrás éxito."
                      </blockquote>
                      <p className="text-right text-sm text-gray-500 dark:text-gray-400">
                        — Albert Schweitzer
                      </p>
                    </div>
                    
                    <div className="mb-8">
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                        Consejos para mantener la motivación
                      </h3>
                      <div className="space-y-4">
                        <div className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                          <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                            Establece objetivos realistas
                          </h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm">
                            Divide tu preparación en pequeñas metas alcanzables. Celebra cada logro, por pequeño que sea.
                          </p>
                        </div>
                        <div className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                          <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                            Mantén una rutina constante
                          </h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm">
                            Estudiar a la misma hora cada día ayuda a crear un hábito. Tu cerebro se acostumbrará y será más fácil concentrarse.
                          </p>
                        </div>
                        <div className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                          <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                            Cuida tu bienestar físico y mental
                          </h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm">
                            Duerme bien, come saludablemente y haz ejercicio regularmente. Un cuerpo sano facilita un estudio eficiente.
                          </p>
                        </div>
                        <div className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                          <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                            Visualiza tu éxito
                          </h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm">
                            Imagínate aprobando la oposición y cumpliendo tu objetivo. Esta visualización positiva te ayudará en momentos difíciles.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                        Recursos motivacionales
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <button className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:shadow transition-shadow text-left">
                          <h4 className="font-medium text-gray-900 dark:text-white mb-1">
                            Meditación guiada para opositores
                          </h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm">
                            10 minutos para reducir el estrés y aumentar la concentración
                          </p>
                        </button>
                        <button className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:shadow transition-shadow text-left">
                          <h4 className="font-medium text-gray-900 dark:text-white mb-1">
                            Testimonios de aprobados
                          </h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm">
                            Historias inspiradoras de personas que consiguieron su plaza
                          </p>
                        </button>
                        <button className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:shadow transition-shadow text-left">
                          <h4 className="font-medium text-gray-900 dark:text-white mb-1">
                            Técnicas anti-procrastinación
                          </h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm">
                            Métodos prácticos para vencer la postergación
                          </p>
                        </button>
                        <button className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:shadow transition-shadow text-left">
                          <h4 className="font-medium text-gray-900 dark:text-white mb-1">
                            Playlist motivacional
                          </h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm">
                            Música para estudiar y mantener el enfoque
                          </p>
                        </button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <Card className="mb-6 sticky top-4">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                      Tu diario de progreso
                    </h3>
                    <textarea
                      className="w-full p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 mb-4"
                      rows={6}
                      placeholder="Escribe cómo te sientes hoy, tus logros, dificultades o metas..."
                    ></textarea>
                    <Button 
                      variant="primary" 
                      fullWidth
                    >
                      Guardar entrada
                    </Button>
                    
                    <div className="mt-6">
                      <h4 className="font-medium text-gray-900 dark:text-white mb-3">
                        Entradas recientes
                      </h4>
                      <div className="space-y-3">
                        <div className="p-3 rounded-md bg-gray-50 dark:bg-gray-800">
                          <p className="text-sm text-gray-600 dark:text-gray-300">
                            "Hoy completé el tema 3 y me siento motivado. Los test me están saliendo mejor..."
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            Hace 2 días
                          </p>
                        </div>
                        <div className="p-3 rounded-md bg-gray-50 dark:bg-gray-800">
                          <p className="text-sm text-gray-600 dark:text-gray-300">
                            "Día difícil, me está costando concentrarme. Mañana intentaré cambiar de lugar de estudio..."
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            Hace 5 días
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AsistenteDetailPage;