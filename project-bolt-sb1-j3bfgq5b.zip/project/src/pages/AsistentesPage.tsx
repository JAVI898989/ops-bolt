import React, { useState } from 'react';
import { Search, MessageSquare, BookOpen, FileText, LineChart, Smile, ArrowRight } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';

const AsistentesPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('oposiciones');

  // Datos de ejemplo para asistentes de oposiciones
  const asistentesOposiciones = [
    {
      id: 1,
      title: 'Auxiliar Administrativo',
      category: 'Administración',
      description: 'Asistente especializado en la preparación de oposiciones para Auxiliar Administrativo del Estado.',
      features: ['Temario completo', 'Tests personalizados', 'Simulacros de examen', 'Seguimiento de progreso'],
      icon: <MessageSquare className="h-6 w-6" />,
      color: 'blue',
      price: 19.99
    },
    {
      id: 2,
      title: 'Policía Nacional',
      category: 'Seguridad',
      description: 'Asistente especializado en la preparación de oposiciones para Policía Nacional (Escala Básica).',
      features: ['Temario actualizado', 'Tests de aptitud física', 'Preparación psicotécnica', 'Ortografía y gramática'],
      icon: <MessageSquare className="h-6 w-6" />,
      color: 'green',
      price: 24.99
    },
    {
      id: 3,
      title: 'Maestro de Primaria',
      category: 'Educación',
      description: 'Asistente especializado en la preparación de oposiciones para Maestro de Educación Primaria.',
      features: ['Temario específico', 'Preparación de unidades didácticas', 'Técnicas de exposición oral', 'Legislación educativa'],
      icon: <MessageSquare className="h-6 w-6" />,
      color: 'purple',
      price: 22.99
    },
    {
      id: 4,
      title: 'Enfermería',
      category: 'Sanidad',
      description: 'Asistente especializado en la preparación de oposiciones para Enfermería del Sistema Nacional de Salud.',
      features: ['Temario médico actualizado', 'Casos clínicos prácticos', 'Tests específicos por comunidad', 'Protocolos sanitarios'],
      icon: <MessageSquare className="h-6 w-6" />,
      color: 'red',
      price: 24.99
    },
    {
      id: 5,
      title: 'Correos',
      category: 'Otros',
      description: 'Asistente especializado en la preparación de oposiciones para Personal Laboral de Correos.',
      features: ['Temario completo', 'Tests de aptitud', 'Pruebas psicotécnicas', 'Atención al cliente'],
      icon: <MessageSquare className="h-6 w-6" />,
      color: 'yellow',
      price: 19.99
    },
    {
      id: 6,
      title: 'Hacienda',
      category: 'Economía',
      description: 'Asistente especializado en la preparación de oposiciones para Agente de Hacienda Pública.',
      features: ['Temario fiscal', 'Contabilidad', 'Casos prácticos', 'Legislación tributaria'],
      icon: <MessageSquare className="h-6 w-6" />,
      color: 'blue',
      price: 22.99
    },
  ];

  // Datos de ejemplo para asistentes especiales
  const asistentesEspeciales = [
    {
      id: 101,
      title: 'Nutrición y Deporte',
      category: 'Estilo de vida',
      description: 'Asistente especializado en nutrición, planificación dietética y entrenamiento físico para opositores.',
      features: ['Dietas personalizadas', 'Planes de entrenamiento', 'Suplementación', 'Recetas saludables'],
      icon: <Smile className="h-6 w-6" />,
      color: 'green',
      price: 14.99
    },
    {
      id: 102,
      title: 'Inglés',
      category: 'Idiomas',
      description: 'Asistente especializado en el aprendizaje y perfeccionamiento del inglés para opositores.',
      features: ['Gramática', 'Vocabulario específico', 'Conversación', 'Preparación para exámenes oficiales'],
      icon: <BookOpen className="h-6 w-6" />,
      color: 'blue',
      price: 14.99
    },
    {
      id: 103,
      title: 'Francés',
      category: 'Idiomas',
      description: 'Asistente especializado en el aprendizaje y perfeccionamiento del francés para opositores.',
      features: ['Gramática', 'Vocabulario específico', 'Conversación', 'Preparación para exámenes oficiales'],
      icon: <BookOpen className="h-6 w-6" />,
      color: 'red',
      price: 14.99
    },
    {
      id: 104,
      title: 'Motivación y Productividad',
      category: 'Desarrollo personal',
      description: 'Asistente especializado en técnicas de motivación, productividad y gestión del estrés para opositores.',
      features: ['Técnicas de motivación', 'Gestión del tiempo', 'Reducción del estrés', 'Hábitos productivos'],
      icon: <Smile className="h-6 w-6" />,
      color: 'purple',
      price: 12.99
    },
  ];

  // Filtrar asistentes según la búsqueda
  const filteredAsistentesOposiciones = asistentesOposiciones.filter(
    asistente => asistente.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    asistente.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    asistente.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredAsistentesEspeciales = asistentesEspeciales.filter(
    asistente => asistente.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    asistente.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    asistente.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getColorClasses = (color: string) => {
    switch(color) {
      case 'blue':
        return 'bg-blue-100 dark:bg-blue-900/20 text-blue-900 dark:text-blue-400';
      case 'green':
        return 'bg-green-100 dark:bg-green-900/20 text-green-900 dark:text-green-400';
      case 'purple':
        return 'bg-purple-100 dark:bg-purple-900/20 text-purple-900 dark:text-purple-400';
      case 'red':
        return 'bg-red-100 dark:bg-red-900/20 text-red-900 dark:text-red-400';
      case 'yellow':
        return 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-900 dark:text-yellow-400';
      default:
        return 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-8 pb-16">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mb-12">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Asistentes IA
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Explora nuestros asistentes especializados para preparar tus oposiciones y mejorar tu rendimiento
          </p>
        </div>
        
        {/* Búsqueda */}
        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Buscar asistente..."
              className="pl-10 pr-4 py-2 w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 dark:text-gray-100"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        
        {/* Tabs */}
        <div className="flex border-b border-gray-200 dark:border-gray-700 mb-8">
          <button
            className={`py-2 px-4 font-medium text-sm ${
              activeTab === 'oposiciones'
                ? 'text-blue-900 dark:text-blue-400 border-b-2 border-blue-900 dark:border-blue-400'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('oposiciones')}
          >
            Asistentes para Oposiciones
          </button>
          <button
            className={`py-2 px-4 font-medium text-sm ${
              activeTab === 'especiales'
                ? 'text-blue-900 dark:text-blue-400 border-b-2 border-blue-900 dark:border-blue-400'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('especiales')}
          >
            Asistentes Especiales
          </button>
        </div>
        
        {/* Listado de asistentes */}
        {activeTab === 'oposiciones' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAsistentesOposiciones.map((asistente) => (
              <Card key={asistente.id} hoverable className="h-full">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 rounded-lg ${getColorClasses(asistente.color)} flex items-center justify-center mb-4`}>
                    {asistente.icon}
                  </div>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                      {asistente.title}
                    </h3>
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200">
                      {asistente.category}
                    </span>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    {asistente.description}
                  </p>
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Características:
                    </h4>
                    <ul className="space-y-1">
                      {asistente.features.map((feature, index) => (
                        <li key={index} className="flex items-start text-sm">
                          <span className="text-green-500 mr-2">✓</span>
                          <span className="text-gray-600 dark:text-gray-400">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-auto pt-4 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
                    <div className="text-lg font-bold text-gray-900 dark:text-white">
                      {asistente.price}€<span className="text-sm font-normal text-gray-500 dark:text-gray-400">/mes</span>
                    </div>
                    <Button 
                      variant="primary" 
                      size="sm"
                      rightIcon={<ArrowRight size={16} />}
                      onClick={() => window.location.href = `/asistente/${asistente.id}`}
                    >
                      Seleccionar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        
        {activeTab === 'especiales' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAsistentesEspeciales.map((asistente) => (
              <Card key={asistente.id} hoverable className="h-full">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 rounded-lg ${getColorClasses(asistente.color)} flex items-center justify-center mb-4`}>
                    {asistente.icon}
                  </div>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                      {asistente.title}
                    </h3>
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200">
                      {asistente.category}
                    </span>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    {asistente.description}
                  </p>
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Características:
                    </h4>
                    <ul className="space-y-1">
                      {asistente.features.map((feature, index) => (
                        <li key={index} className="flex items-start text-sm">
                          <span className="text-green-500 mr-2">✓</span>
                          <span className="text-gray-600 dark:text-gray-400">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-auto pt-4 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
                    <div className="text-lg font-bold text-gray-900 dark:text-white">
                      {asistente.price}€<span className="text-sm font-normal text-gray-500 dark:text-gray-400">/mes</span>
                    </div>
                    <Button 
                      variant="primary" 
                      size="sm"
                      rightIcon={<ArrowRight size={16} />}
                      onClick={() => window.location.href = `/asistente/${asistente.id}`}
                    >
                      Seleccionar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        
        {/* Mensaje si no hay resultados */}
        {((activeTab === 'oposiciones' && filteredAsistentesOposiciones.length === 0) ||
          (activeTab === 'especiales' && filteredAsistentesEspeciales.length === 0)) && (
          <div className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-300 text-lg">
              No se encontraron asistentes que coincidan con tu búsqueda.
            </p>
          </div>
        )}
        
        {/* Planes completos */}
        <div className="mt-16 bg-blue-50 dark:bg-blue-900/10 rounded-lg p-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
              Plan completo
            </h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Accede a todos nuestros asistentes por un precio especial
            </p>
          </div>
          
          <div className="max-w-md mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
            <div className="bg-blue-900 dark:bg-blue-950 p-6 text-white text-center">
              <h3 className="text-xl font-bold mb-2">Acceso Premium</h3>
              <div className="text-3xl font-bold mb-1">39,99€<span className="text-sm font-normal">/mes</span></div>
              <p className="text-blue-100 text-sm">Acceso ilimitado a todos los asistentes</p>
            </div>
            
            <div className="p-6">
              <ul className="space-y-3 mb-6">
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-700 dark:text-gray-300">Todos los asistentes de oposiciones</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-700 dark:text-gray-300">Todos los asistentes especiales</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-700 dark:text-gray-300">Funcionalidades premium</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-700 dark:text-gray-300">Actualizaciones prioritarias</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-700 dark:text-gray-300">Soporte preferente</span>
                </li>
              </ul>
              
              <Button variant="primary" fullWidth>
                Suscribirme al plan completo
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AsistentesPage;