import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/Tabs';
import Button from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { BookOpen, FileText, MessageSquare, LineChart, Smile, ChevronRight, Clock, Award, Users, Bookmark } from 'lucide-react';

const OposicionDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState('informacion');

  // Datos de ejemplo de la oposición
  const oposicion = {
    id: 1,
    title: 'Auxiliar Administrativo del Estado',
    category: 'Administración General del Estado',
    description: 'Oposición para acceder al Cuerpo de Auxiliares Administrativos del Estado.',
    fullDescription: `
      El Cuerpo de Auxiliares Administrativos del Estado es uno de los cuerpos más demandados en la Administración General del Estado. Los funcionarios de este cuerpo realizan tareas administrativas de apoyo, como atención al público, gestión de documentos, archivo, y tramitación de expedientes administrativos.
      
      Las plazas se convocan anualmente y el proceso selectivo consta de dos ejercicios eliminatorios: un cuestionario tipo test sobre el temario y un ejercicio práctico de ofimática.
    `,
    requirements: [
      'Nacionalidad española o de un estado miembro de la UE',
      'Tener 16 años cumplidos',
      'Estar en posesión del título de Graduado en ESO o equivalente',
      'No haber sido separado del servicio de cualquier Administración Pública'
    ],
    temario: [
      { id: 1, title: 'La Constitución Española de 1978', content: '...' },
      { id: 2, title: 'La organización territorial del Estado', content: '...' },
      { id: 3, title: 'La Administración General del Estado', content: '...' },
      { id: 4, title: 'El procedimiento administrativo común', content: '...' },
      { id: 5, title: 'Los contratos del sector público', content: '...' },
      { id: 6, title: 'El presupuesto del Estado', content: '...' },
      { id: 7, title: 'La gestión económica y financiera', content: '...' },
      { id: 8, title: 'Los empleados públicos', content: '...' },
      { id: 9, title: 'Ofimática', content: '...' },
      { id: 10, title: 'Atención al ciudadano', content: '...' },
    ],
    image: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800',
    difficulty: 'Media',
    popularity: 95,
    lastUpdate: '2023-05-15',
    plazasUltimaConvocatoria: 1200,
    ratioPlazasAspirantes: '1:20',
    sueldo: '1.360€ - 1.800€ mensuales'
  };
  
  // Testimonios de ejemplo
  const testimonios = [
    {
      id: 1,
      name: 'Laura García',
      role: 'Aprobada en 2022',
      comment: 'Gracias a la preparación con OposIA pude optimizar mi tiempo de estudio y centrarme en los temas realmente importantes. Los tests personalizados fueron clave para mi éxito.',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    {
      id: 2,
      name: 'Carlos Martínez',
      role: 'Aprobado en 2023',
      comment: 'El asistente IA me ayudó a resolver dudas al instante, sin tener que esperar a las clases de la academia. Recomiendo totalmente este sistema de preparación.',
      image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=800'
    }
  ];
  
  // Elementos de la prepa
  const preparationFeatures = [
    {
      icon: <MessageSquare className="h-6 w-6 text-blue-900 dark:text-blue-400" />,
      title: 'Asistente IA especializado',
      description: 'Resuelve cualquier duda sobre el temario al instante'
    },
    {
      icon: <BookOpen className="h-6 w-6 text-blue-900 dark:text-blue-400" />,
      title: 'Temario actualizado',
      description: 'Contenido adaptado a la última convocatoria'
    },
    {
      icon: <FileText className="h-6 w-6 text-blue-900 dark:text-blue-400" />,
      title: 'Tests ilimitados',
      description: 'Genera tests personalizados para cada tema y nivel'
    },
    {
      icon: <LineChart className="h-6 w-6 text-blue-900 dark:text-blue-400" />,
      title: 'Seguimiento de progreso',
      description: 'Analiza tu evolución y refuerza tus puntos débiles'
    },
    {
      icon: <Smile className="h-6 w-6 text-blue-900 dark:text-blue-400" />,
      title: 'Asistente motivacional',
      description: 'Te ayuda a mantener la constancia y superar los momentos difíciles'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pt-8 pb-16">
      <div className="container mx-auto px-4 md:px-6">
        {/* Cabecera */}
        <div className="mb-8">
          <div className="text-sm breadcrumbs text-gray-500 dark:text-gray-400 mb-4">
            <ul className="flex space-x-2">
              <li><a href="/oposiciones">Oposiciones</a></li>
              <li><ChevronRight className="h-4 w-4" /></li>
              <li><a href={`/oposiciones/${oposicion.category.toLowerCase().replace(/ /g, '-')}`}>{oposicion.category}</a></li>
              <li><ChevronRight className="h-4 w-4" /></li>
              <li>{oposicion.title}</li>
            </ul>
          </div>
          
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-2/3">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                {oposicion.title}
              </h1>
              <p className="text-lg text-gray-600 dark:text-gray-300 mb-6">
                {oposicion.description}
              </p>
              
              <div className="flex flex-wrap gap-4 mb-6">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-900 dark:text-blue-200">
                  <Clock className="mr-1 h-3 w-3" /> Última actualización: {new Date(oposicion.lastUpdate).toLocaleDateString('es-ES')}
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900 text-green-900 dark:text-green-200">
                  <Award className="mr-1 h-3 w-3" /> Dificultad: {oposicion.difficulty}
                </span>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-orange-100 dark:bg-orange-900 text-orange-900 dark:text-orange-200">
                  <Users className="mr-1 h-3 w-3" /> Popularidad: {oposicion.popularity}%
                </span>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  variant="primary"
                  rightIcon={<ChevronRight size={18} />}
                >
                  Empezar preparación
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  leftIcon={<Bookmark size={18} />}
                >
                  Guardar para después
                </Button>
              </div>
            </div>
            
            <div className="md:w-1/3">
              <div className="rounded-lg overflow-hidden shadow-md">
                <img 
                  src={oposicion.image} 
                  alt={oposicion.title} 
                  className="w-full h-48 object-cover"
                />
                <div className="bg-white dark:bg-gray-800 p-4">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                    Información clave
                  </h3>
                  <div className="space-y-2 text-sm">
                    <p className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">Plazas última convocatoria:</span>
                      <span className="font-medium text-gray-900 dark:text-white">{oposicion.plazasUltimaConvocatoria}</span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">Ratio plazas/aspirantes:</span>
                      <span className="font-medium text-gray-900 dark:text-white">{oposicion.ratioPlazasAspirantes}</span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">Sueldo aproximado:</span>
                      <span className="font-medium text-gray-900 dark:text-white">{oposicion.sueldo}</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-16">
          <TabsList className="mb-8">
            <TabsTrigger value="informacion">Información</TabsTrigger>
            <TabsTrigger value="temario">Temario</TabsTrigger>
            <TabsTrigger value="requisitos">Requisitos</TabsTrigger>
            <TabsTrigger value="preparacion">Preparación</TabsTrigger>
            <TabsTrigger value="testimonios">Testimonios</TabsTrigger>
          </TabsList>
          
          <TabsContent value="informacion" className="mt-6">
            <div className="prose prose-blue dark:prose-invert max-w-none">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                Sobre esta oposición
              </h2>
              <div className="text-gray-700 dark:text-gray-300 mb-6 whitespace-pre-line">
                {oposicion.fullDescription}
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                ¿Por qué elegir esta oposición?
              </h3>
              <ul className="list-disc pl-5 space-y-2 text-gray-700 dark:text-gray-300">
                <li>Gran número de plazas convocadas anualmente</li>
                <li>Estabilidad laboral y desarrollo profesional en la Administración</li>
                <li>Posibilidad de trabajar en diversos organismos y ministerios</li>
                <li>Conciliación laboral y familiar</li>
                <li>Posibilidades de promoción interna</li>
              </ul>
            </div>
          </TabsContent>
          
          <TabsContent value="temario" className="mt-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Temario completo
            </h2>
            <div className="grid gap-4">
              {oposicion.temario.map((tema, index) => (
                <div 
                  key={tema.id}
                  className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                >
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-900 dark:text-blue-200 flex items-center justify-center font-medium mr-3">
                      {index + 1}
                    </div>
                    <h3 className="font-medium text-gray-900 dark:text-white">
                      {tema.title}
                    </h3>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 text-center">
              <Button variant="primary">Ver temario completo</Button>
            </div>
          </TabsContent>
          
          <TabsContent value="requisitos" className="mt-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Requisitos para presentarse
            </h2>
            <Card>
              <CardContent className="p-6">
                <ul className="space-y-3">
                  {oposicion.requirements.map((req, index) => (
                    <li key={index} className="flex items-start">
                      <div className="flex-shrink-0 w-5 h-5 rounded-full bg-green-500 text-white flex items-center justify-center mr-3 mt-0.5">
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </div>
                      <span className="text-gray-700 dark:text-gray-300">{req}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="preparacion" className="mt-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Preparación con OposIA
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {preparationFeatures.map((feature, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-full inline-block">
                      {feature.icon}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="bg-blue-50 dark:bg-blue-900/10 rounded-lg p-6 border border-blue-200 dark:border-blue-800">
              <h3 className="text-xl font-semibold text-blue-900 dark:text-blue-400 mb-3">
                Beneficios de prepararte con nosotros
              </h3>
              <ul className="space-y-2 text-gray-700 dark:text-gray-300">
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Acceso 24/7 a todos los materiales desde cualquier dispositivo</span>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Ahorro de tiempo al tener todo centralizado en una sola plataforma</span>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Contenido personalizado según tu nivel y ritmo de estudio</span>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center mr-3 mt-0.5">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M10 3L4.5 8.5L2 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Estadísticas detalladas para optimizar tu preparación</span>
                </li>
              </ul>
            </div>
          </TabsContent>
          
          <TabsContent value="testimonios" className="mt-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Testimonios de aprobados
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {testimonios.map((testimonio) => (
                <Card key={testimonio.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start mb-4">
                      <img 
                        src={testimonio.image} 
                        alt={testimonio.name} 
                        className="w-12 h-12 rounded-full object-cover mr-4"
                      />
                      <div>
                        <h3 className="font-medium text-gray-900 dark:text-white">
                          {testimonio.name}
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {testimonio.role}
                        </p>
                      </div>
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 italic">
                      "{testimonio.comment}"
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="mt-8 text-center">
              <Button variant="secondary">Ver más testimonios</Button>
            </div>
          </TabsContent>
        </Tabs>
        
        {/* CTA final */}
        <div className="bg-blue-900 dark:bg-blue-950 text-white rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">
            Comienza tu preparación hoy mismo
          </h2>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Accede a nuestra plataforma completa con asistente IA, temarios actualizados y tests personalizados para aprobar tu oposición.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              size="lg" 
              variant="secondary"
            >
              Ver planes y precios
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-white text-white hover:bg-white/10"
            >
              Probar demo
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OposicionDetailPage;