import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, CheckCircle, Award, Users, BrainCircuit } from 'lucide-react';
import Button from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';

const HomePage: React.FC = () => {
  const features = [
    {
      icon: <BookOpen className="h-8 w-8 text-blue-900 dark:text-blue-400" />,
      title: 'Temarios Personalizados',
      description: 'Accede a temarios completos generados por IA, adaptados a tu ritmo y nivel de aprendizaje.',
    },
    {
      icon: <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />,
      title: 'Tests Ilimitados',
      description: 'Genera tests de cualquier tema y dificultad para evaluar y reforzar tus conocimientos.',
    },
    {
      icon: <BrainCircuit className="h-8 w-8 text-orange-600 dark:text-orange-400" />,
      title: 'Asistente IA',
      description: 'Resuelve tus dudas al instante con asistentes especializados en tu oposición.',
    },
    {
      icon: <Award className="h-8 w-8 text-purple-600 dark:text-purple-400" />,
      title: 'Seguimiento de Progreso',
      description: 'Visualiza tu avance, identifica puntos débiles y recibe recomendaciones personalizadas.',
    },
  ];

  const categories = [
    {
      title: 'Administración General',
      count: 12,
      image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800',
      path: '/oposiciones/administracion',
    },
    {
      title: 'Educación',
      count: 8,
      image: 'https://images.pexels.com/photos/3401403/pexels-photo-3401403.jpeg?auto=compress&cs=tinysrgb&w=800',
      path: '/oposiciones/educacion',
    },
    {
      title: 'Sanidad',
      count: 10,
      image: 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=800',
      path: '/oposiciones/sanidad',
    },
    {
      title: 'Seguridad y Policía',
      count: 7,
      image: 'https://images.pexels.com/photos/2504075/pexels-photo-2504075.jpeg?auto=compress&cs=tinysrgb&w=800',
      path: '/oposiciones/seguridad',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-900 to-blue-800 dark:from-blue-950 dark:to-blue-900">
        <div className="container mx-auto px-4 md:px-6 py-16 md:py-24">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
                Prepara tus oposiciones con el poder de la IA
              </h1>
              <p className="text-blue-100 text-lg md:text-xl mb-8">
                OposIA es tu plataforma de preparación con asistentes especializados, temarios personalizados y tests ilimitados para cada oposición.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  variant="secondary"
                  rightIcon={<ArrowRight size={20} />}
                >
                  Empezar ahora
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  className="text-white border-white hover:bg-blue-800/30"
                >
                  Ver oposiciones
                </Button>
              </div>
            </div>
            <div className="md:w-1/2 mt-8 md:mt-0">
              <div className="relative">
                <div className="absolute -top-6 -left-6 w-24 h-24 bg-green-500 rounded-full opacity-20"></div>
                <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-orange-500 rounded-full opacity-20"></div>
                <img 
                  src="https://images.pexels.com/photos/3807751/pexels-photo-3807751.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Estudiante preparando oposiciones" 
                  className="relative rounded-lg shadow-xl max-w-full h-auto z-10"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-gray-50 dark:from-gray-900 to-transparent"></div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Características principales
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Todo lo que necesitas para preparar y aprobar tus oposiciones de forma eficiente
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border border-gray-200 dark:border-gray-700 h-full">
                <CardContent className="flex flex-col items-center text-center p-6">
                  <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-full">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gray-100 dark:bg-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Categorías populares
              </h2>
              <p className="text-lg text-gray-600 dark:text-gray-300">
                Explora las oposiciones más demandadas en España
              </p>
            </div>
            <Link to="/oposiciones" className="mt-4 md:mt-0 inline-flex items-center text-blue-900 dark:text-blue-400 font-medium hover:text-blue-700 dark:hover:text-blue-300">
              Ver todas las categorías
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {categories.map((category, index) => (
              <Card 
                key={index} 
                className="h-full" 
                hoverable
                onClick={() => window.location.href = category.path}
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={category.image} 
                    alt={category.title} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="text-white text-xl font-bold">{category.title}</h3>
                    <p className="text-gray-200 text-sm">{category.count} oposiciones</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Testimonios de éxito
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Descubre cómo OposIA ha ayudado a otros opositores a conseguir su plaza
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="border border-gray-200 dark:border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="mr-4">
                      <div className="w-12 h-12 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white">Usuario {i}</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Opositor a {i === 1 ? 'Educación' : i === 2 ? 'Administración' : 'Sanidad'}</p>
                    </div>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 italic">
                    "Gracias a OposIA conseguí preparar mi oposición en tiempo récord. Los tests personalizados y el asistente IA me ayudaron a reforzar mis puntos débiles."
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-900 dark:bg-blue-950">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Comienza tu preparación hoy mismo
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Únete a miles de opositores que ya están aprovechando el poder de la IA para preparar sus oposiciones
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            rightIcon={<Users size={20} />}
          >
            Crear cuenta
          </Button>
        </div>
      </section>
    </div>
  );
};

export default HomePage;