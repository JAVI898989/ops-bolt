export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  createdAt: Date;
  role: 'user' | 'admin';
  subscription?: Subscription;
  referralCode: string;
  referredBy?: string;
}

export interface Subscription {
  id: string;
  userId: string;
  plan: 'single' | 'complete';
  assistantId?: string;
  active: boolean;
  startDate: Date;
  endDate: Date;
  autoRenew: boolean;
  price: number;
}

export interface Assistant {
  id: string;
  name: string;
  category: Category;
  description: string;
  icon: string;
  features: string[];
  price: number;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctOption: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  topicId: string;
}

export interface Topic {
  id: string;
  title: string;
  content: string;
  assistantId: string;
}

export interface Test {
  id: string;
  userId: string;
  assistantId: string;
  questions: Question[];
  answers: number[];
  score: number;
  date: Date;
  completed: boolean;
}

export interface Progress {
  userId: string;
  assistantId: string;
  topicsCompleted: string[];
  testsCompleted: number;
  averageScore: number;
  studyTime: number;
  lastActive: Date;
}

export interface ChatMessage {
  id: string;
  userId: string;
  assistantId: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

export interface Referral {
  id: string;
  referrerId: string;
  referredId: string;
  date: Date;
  status: 'pending' | 'complete';
  discountApplied: boolean;
}