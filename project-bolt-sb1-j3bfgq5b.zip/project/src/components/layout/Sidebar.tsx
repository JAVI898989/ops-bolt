import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  BookOpen, 
  Users, 
  PieChart, 
  MessageSquare, 
  FileText, 
  CheckSquare, 
  LineChart, 
  Award, 
  Utensils, 
  Smile, 
  GraduationCap,
  Briefcase,
  Scale,
  HeartPulse,
  Lightbulb,
  Shield,
  Flame,
  Building,
  Mail,
  Leaf,
  X
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar }) => {
  const location = useLocation();

  const mainCategories = [
    { name: 'Inicio', path: '/', icon: <Home size={20} /> },
    { name: 'Asistentes', path: '/asistentes', icon: <MessageSquare size={20} /> },
    { name: 'Oposiciones', path: '/oposiciones', icon: <BookOpen size={20} /> },
    { name: 'Mi Progreso', path: '/progreso', icon: <LineChart size={20} /> },
    { name: 'Referidos', path: '/referidos', icon: <Users size={20} /> },
  ];

  const oposicionesCategories = [
    { name: 'Administración General', path: '/oposiciones/administracion', icon: <Building size={20} /> },
    { name: 'Justicia', path: '/oposiciones/justicia', icon: <Scale size={20} /> },
    { name: 'Hacienda y Economía', path: '/oposiciones/hacienda', icon: <PieChart size={20} /> },
    { name: 'Sanidad', path: '/oposiciones/sanidad', icon: <HeartPulse size={20} /> },
    { name: 'Educación', path: '/oposiciones/educacion', icon: <GraduationCap size={20} /> },
    { name: 'Seguridad y Policía', path: '/oposiciones/seguridad', icon: <Shield size={20} /> },
    { name: 'Bomberos', path: '/oposiciones/bomberos', icon: <Flame size={20} /> },
    { name: 'Instituciones Penitenciarias', path: '/oposiciones/penitenciarias', icon: <Building size={20} /> },
    { name: 'Otros', path: '/oposiciones/otros', icon: <Mail size={20} /> },
    { name: 'Medioambientales', path: '/oposiciones/medioambientales', icon: <Leaf size={20} /> },
    { name: 'Militares', path: '/oposiciones/militares', icon: <Award size={20} /> },
  ];

  const asistentesEspeciales = [
    { name: 'Nutrición y Deporte', path: '/asistentes/nutricion', icon: <Utensils size={20} /> },
    { name: 'Idiomas', path: '/asistentes/idiomas', icon: <GraduationCap size={20} /> },
    { name: 'Motivación', path: '/asistentes/motivacion', icon: <Smile size={20} /> },
  ];

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300"
          onClick={toggleSidebar}
          aria-hidden="true"
        />
      )}
      
      {/* Sidebar */}
      <aside 
        className={`fixed top-0 left-0 h-screen w-64 bg-white dark:bg-gray-900 shadow-lg transform transition-transform duration-300 ease-in-out z-50 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-16 flex items-center justify-between px-4 border-b border-gray-200 dark:border-gray-800">
          <Link to="/" className="flex items-center">
            <span className="text-xl font-bold text-blue-900 dark:text-blue-400">Opos<span className="text-green-600 dark:text-green-400">IA</span></span>
          </Link>
        </div>
        
        <div className="overflow-y-auto h-[calc(100vh-4rem)] pb-20">
          <nav className="px-2 py-4">
            <div className="space-y-1">
              {mainCategories.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive(item.path)
                      ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-900 dark:text-blue-400'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                  }`}
                  onClick={toggleSidebar}
                >
                  <span className="mr-3">{item.icon}</span>
                  {item.name}
                </Link>
              ))}
            </div>
            
            <div className="mt-8">
              <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Categorías de Oposiciones
              </h3>
              <div className="mt-2 space-y-1">
                {oposicionesCategories.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive(item.path)
                        ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-900 dark:text-blue-400'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    }`}
                    onClick={toggleSidebar}
                  >
                    <span className="mr-3">{item.icon}</span>
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>
            
            <div className="mt-8">
              <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Asistentes Especiales
              </h3>
              <div className="mt-2 space-y-1">
                {asistentesEspeciales.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive(item.path)
                        ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-900 dark:text-blue-400'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    }`}
                    onClick={toggleSidebar}
                  >
                    <span className="mr-3">{item.icon}</span>
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>
          </nav>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;