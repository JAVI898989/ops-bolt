import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/layout/Header';
import Sidebar from './components/layout/Sidebar';
import HomePage from './pages/HomePage';
import OposicionesPage from './pages/OposicionesPage';
import OposicionDetailPage from './pages/OposicionDetailPage';
import AsistentesPage from './pages/AsistentesPage';
import AsistenteDetailPage from './pages/AsistenteDetailPage';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <Header />
        <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
        
        {/* Floating Menu Button */}
        <button
          onClick={toggleSidebar}
          className="fixed left-4 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full bg-blue-900 dark:bg-blue-800 text-white shadow-lg hover:bg-blue-800 dark:hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          aria-label="Toggle menu"
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            {sidebarOpen ? (
              <path d="M18 6L6 18M6 6l12 12" />
            ) : (
              <>
                <line x1="3" y1="12" x2="21" y2="12" />
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="3" y1="18" x2="21" y2="18" />
              </>
            )}
          </svg>
        </button>
        
        <main className={`transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-0'}`}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/oposiciones" element={<OposicionesPage />} />
            <Route path="/oposicion/:id" element={<OposicionDetailPage />} />
            <Route path="/asistentes" element={<AsistentesPage />} />
            <Route path="/asistente/:id" element={<AsistenteDetailPage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;