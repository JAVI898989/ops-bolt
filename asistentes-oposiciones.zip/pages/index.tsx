export default function Home() {
  return (
    <main className="p-6">...</main>
  );
}