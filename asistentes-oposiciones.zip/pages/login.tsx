export default function Login() {
  return (
    <div className="max-w-md mx-auto mt-20 p-6 bg-white rounded-xl shadow-md">...</div>
  );
}